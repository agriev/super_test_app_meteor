var require = meteorInstall({"super_test_app_meteor.js":function(){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// super_test_app_meteor.js                                                           //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Tasks = new Mongo.Collection("tasks");                                                // 1
                                                                                      //
if (Meteor.isServer) {                                                                // 3
  // This code only runs on the server                                                //
  Meteor.publish("tasks", function () {                                               // 5
    // return Tasks.find({                                                            //
    //   $or: [                                                                       //
    //     { private: {$ne: true} },                                                  //
    //     { owner: this.userId }                                                     //
    //   ]                                                                            //
    // });                                                                            //
    return Tasks.find({});                                                            // 12
  });                                                                                 //
}                                                                                     //
                                                                                      //
if (Meteor.isClient) {                                                                // 16
  // This code only runs on the client                                                //
  Meteor.subscribe("tasks");                                                          // 18
                                                                                      //
  Template.body.helpers({                                                             // 20
    tasks: function () {                                                              // 21
      function tasks() {                                                              // 21
        if (Session.get("hideCompleted")) {                                           // 22
          // If hide completed is checked, filter tasks                               //
          return Tasks.find({ checked: { $ne: true } }, { sort: { createdAt: -1 } });
        } else {                                                                      //
          // Otherwise, return all of the tasks                                       //
          return Tasks.find({}, { sort: { createdAt: -1 } });                         // 27
        }                                                                             //
      }                                                                               //
                                                                                      //
      return tasks;                                                                   //
    }(),                                                                              //
    hideCompleted: function () {                                                      // 30
      function hideCompleted() {                                                      // 30
        return Session.get("hideCompleted");                                          // 31
      }                                                                               //
                                                                                      //
      return hideCompleted;                                                           //
    }(),                                                                              //
    incompleteCount: function () {                                                    // 33
      function incompleteCount() {                                                    // 33
        return Tasks.find({ checked: { $ne: true } }).count();                        // 34
      }                                                                               //
                                                                                      //
      return incompleteCount;                                                         //
    }()                                                                               //
  });                                                                                 //
  Template.body.events({                                                              // 37
    "submit .new-task": function () {                                                 // 38
      function submitNewTask(event) {                                                 // 38
        // Prevent default browser form submit                                        //
        event.preventDefault();                                                       // 40
        //console.log(event);                                                         //
        // Get value from form element                                                //
        var text = event.target.text.value;                                           // 38
        var address = event.target.address.value;                                     // 44
        var type = event.target.type.value;                                           // 45
        // Insert a task into the collection                                          //
        Meteor.call("addTask", text, address, type);                                  // 38
                                                                                      //
        // Clear form                                                                 //
        event.target.text.value = "";                                                 // 38
        event.target.address.value = "";                                              // 51
        event.target.type.value = "";                                                 // 52
      }                                                                               //
                                                                                      //
      return submitNewTask;                                                           //
    }(),                                                                              //
    "change .hide-completed input": function () {                                     // 54
      function changeHideCompletedInput(event) {                                      // 54
        Session.set("hideCompleted", event.target.checked);                           // 55
      }                                                                               //
                                                                                      //
      return changeHideCompletedInput;                                                //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Template.task.helpers({                                                             // 59
    isOwner: function () {                                                            // 60
      function isOwner() {                                                            // 60
        return this.owner === Meteor.userId();                                        // 61
      }                                                                               //
                                                                                      //
      return isOwner;                                                                 //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Template.task.events({                                                              // 65
    "click .toggle-checked": function () {                                            // 66
      function clickToggleChecked() {                                                 // 66
        // Set the checked property to the opposite of its current value              //
        Meteor.call("setChecked", this._id, !this.checked);                           // 68
      }                                                                               //
                                                                                      //
      return clickToggleChecked;                                                      //
    }(),                                                                              //
    "click .delete": function () {                                                    // 70
      function clickDelete() {                                                        // 70
        Meteor.call("deleteTask", this._id);                                          // 71
      }                                                                               //
                                                                                      //
      return clickDelete;                                                             //
    }(),                                                                              //
    "click .reject": function () {                                                    // 73
      function clickReject() {                                                        // 73
        Meteor.call("deleteTask", this._id);                                          // 74
      }                                                                               //
                                                                                      //
      return clickReject;                                                             //
    }(),                                                                              //
    "click .toggle-private": function () {                                            // 76
      function clickTogglePrivate() {                                                 // 76
        Meteor.call("setPrivate", this._id, !this["private"]);                        // 77
      }                                                                               //
                                                                                      //
      return clickTogglePrivate;                                                      //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Accounts.ui.config({                                                                // 81
    passwordSignupFields: "USERNAME_ONLY"                                             // 82
  });                                                                                 //
}                                                                                     //
                                                                                      //
Meteor.methods({                                                                      // 86
  addTask: function () {                                                              // 87
    function addTask(text, address, type) {                                           // 87
      // Make sure the user is logged in before inserting a task                      //
                                                                                      //
      Tasks.insert({                                                                  // 91
        text: text,                                                                   // 92
        createdAt: new Date(),                                                        // 93
        address: address,                                                             // 94
        type: type                                                                    // 95
      });                                                                             //
    }                                                                                 //
                                                                                      //
    return addTask;                                                                   //
  }(),                                                                                //
  // private : false,                                                                 //
  // username: Meteor.user().username                                                 //
  deleteTask: function () {                                                           // 100
    function deleteTask(taskId) {                                                     // 100
      var task = Tasks.findOne(taskId);                                               // 101
      if (task["private"] && task.owner !== Meteor.userId()) {                        // 102
        // If the task is private, make sure only the owner can delete it             //
        throw new Meteor.Error("not-authorized");                                     // 104
      }                                                                               //
                                                                                      //
      Tasks.remove(taskId);                                                           // 107
    }                                                                                 //
                                                                                      //
    return deleteTask;                                                                //
  }(),                                                                                //
  setChecked: function () {                                                           // 109
    function setChecked(taskId, _setChecked) {                                        // 109
      var task = Tasks.findOne(taskId);                                               // 110
      if (task["private"] && task.owner !== Meteor.userId()) {                        // 111
        // If the task is private, make sure only the owner can check it off          //
        throw new Meteor.Error("not-authorized");                                     // 113
      }                                                                               //
      Tasks.update(taskId, { $set: { checked: _setChecked } });                       // 115
    }                                                                                 //
                                                                                      //
    return setChecked;                                                                //
  }(),                                                                                //
  setPrivate: function () {                                                           // 117
    function setPrivate(taskId, setToPrivate) {                                       // 117
      var task = Tasks.findOne(taskId);                                               // 118
                                                                                      //
      // Make sure only the task owner can make a task private                        //
      if (task.owner !== Meteor.userId()) {                                           // 117
        throw new Meteor.Error("not-authorized");                                     // 122
      }                                                                               //
                                                                                      //
      Tasks.update(taskId, { $set: { "private": setToPrivate } });                    // 125
    }                                                                                 //
                                                                                      //
    return setPrivate;                                                                //
  }()                                                                                 //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./super_test_app_meteor.js");
//# sourceMappingURL=app.js.map
