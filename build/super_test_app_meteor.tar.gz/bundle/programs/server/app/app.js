var require = meteorInstall({"super_test_app_meteor.js":function(){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// super_test_app_meteor.js                                                           //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
Tasks = new Mongo.Collection("tasks");                                                // 1
                                                                                      //
if (Meteor.isServer) {                                                                // 3
  // This code only runs on the server                                                //
  Meteor.publish("tasks", function () {                                               // 5
    // return Tasks.find({                                                            //
    //   $or: [                                                                       //
    //     { private: {$ne: true} },                                                  //
    //     { owner: this.userId }                                                     //
    //   ]                                                                            //
    // });                                                                            //
    return Tasks.find({});                                                            // 12
  });                                                                                 //
}                                                                                     //
                                                                                      //
if (Meteor.isClient) {                                                                // 18
  // This code only runs on the client                                                //
  Meteor.subscribe("tasks");                                                          // 20
                                                                                      //
  var MAP_ZOOM = 15;                                                                  // 22
                                                                                      //
  Meteor.startup(function () {                                                        // 24
    GoogleMaps.load();                                                                // 25
  });                                                                                 //
                                                                                      //
  Template.body.helpers({                                                             // 28
    tasks: function () {                                                              // 29
      function tasks() {                                                              // 29
        if (Session.get("hideCompleted")) {                                           // 30
          // If hide completed is checked, filter tasks                               //
          return Tasks.find({ checked: { $ne: true } }, { sort: { createdAt: -1 } });
        } else {                                                                      //
          // Otherwise, return all of the tasks                                       //
          return Tasks.find({}, { sort: { createdAt: -1 } });                         // 35
        }                                                                             //
      }                                                                               //
                                                                                      //
      return tasks;                                                                   //
    }(),                                                                              //
    hideCompleted: function () {                                                      // 38
      function hideCompleted() {                                                      // 38
        return Session.get("hideCompleted");                                          // 39
      }                                                                               //
                                                                                      //
      return hideCompleted;                                                           //
    }(),                                                                              //
    incompleteCount: function () {                                                    // 41
      function incompleteCount() {                                                    // 41
        return Tasks.find({ checked: { $ne: true } }).count();                        // 42
      }                                                                               //
                                                                                      //
      return incompleteCount;                                                         //
    }(),                                                                              //
    exampleMapOptions: function () {                                                  // 44
      function exampleMapOptions() {                                                  // 44
        // Make sure the maps API has loaded                                          //
        if (GoogleMaps.loaded()) {                                                    // 46
          // Map initialization options                                               //
          return {                                                                    // 48
            center: new google.maps.LatLng(-37.8136, 144.9631),                       // 49
            zoom: 8                                                                   // 50
          };                                                                          //
        }                                                                             //
      }                                                                               //
                                                                                      //
      return exampleMapOptions;                                                       //
    }()                                                                               //
  });                                                                                 //
  Template.body.events({                                                              // 55
    "submit .new-task": function () {                                                 // 56
      function submitNewTask(event) {                                                 // 56
        // Prevent default browser form submit                                        //
        event.preventDefault();                                                       // 58
        //console.log(event);                                                         //
        // Get value from form element                                                //
        var text = event.target.text.value;                                           // 56
        var address = event.target.address.value;                                     // 62
        var type = event.target.type.value;                                           // 63
        // Insert a task into the collection                                          //
        Meteor.call("addTask", text, address, type);                                  // 56
                                                                                      //
        // Clear form                                                                 //
        event.target.text.value = "";                                                 // 56
        event.target.address.value = "";                                              // 69
        event.target.type.value = "";                                                 // 70
      }                                                                               //
                                                                                      //
      return submitNewTask;                                                           //
    }(),                                                                              //
    "change .hide-completed input": function () {                                     // 72
      function changeHideCompletedInput(event) {                                      // 72
        Session.set("hideCompleted", event.target.checked);                           // 73
      }                                                                               //
                                                                                      //
      return changeHideCompletedInput;                                                //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Template.task.helpers({                                                             // 77
    isOwner: function () {                                                            // 78
      function isOwner() {                                                            // 78
        return this.owner === Meteor.userId();                                        // 79
      }                                                                               //
                                                                                      //
      return isOwner;                                                                 //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Template.task.events({                                                              // 83
    "click .toggle-checked": function () {                                            // 84
      function clickToggleChecked() {                                                 // 84
        // Set the checked property to the opposite of its current value              //
        Meteor.call("setChecked", this._id, !this.checked);                           // 86
      }                                                                               //
                                                                                      //
      return clickToggleChecked;                                                      //
    }(),                                                                              //
    "click .delete": function () {                                                    // 88
      function clickDelete() {                                                        // 88
        Meteor.call("deleteTask", this._id);                                          // 89
      }                                                                               //
                                                                                      //
      return clickDelete;                                                             //
    }(),                                                                              //
    "click .reject": function () {                                                    // 91
      function clickReject() {                                                        // 91
        Meteor.call("deleteTask", this._id);                                          // 92
      }                                                                               //
                                                                                      //
      return clickReject;                                                             //
    }(),                                                                              //
    "click .toggle-private": function () {                                            // 94
      function clickTogglePrivate() {                                                 // 94
        Meteor.call("setPrivate", this._id, !this["private"]);                        // 95
      }                                                                               //
                                                                                      //
      return clickTogglePrivate;                                                      //
    }(),                                                                              //
    "click .accept": function () {                                                    // 97
      function clickAccept() {                                                        // 97
        $(".map-container").show();                                                   // 98
      }                                                                               //
                                                                                      //
      return clickAccept;                                                             //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Template.body.onCreated(function () {                                               // 102
    var self = this;                                                                  // 103
                                                                                      //
    GoogleMaps.ready('map', function (map) {                                          // 105
      var marker;                                                                     // 106
                                                                                      //
      // Create and move the marker when latLng changes.                              //
      self.autorun(function () {                                                      // 105
        var latLng = Geolocation.latLng();                                            // 110
        if (!latLng) return;                                                          // 111
                                                                                      //
        // If the marker doesn't yet exist, create it.                                //
        if (!marker) {                                                                // 109
          marker = new google.maps.Marker({                                           // 116
            position: new google.maps.LatLng(latLng.lat, latLng.lng),                 // 117
            map: map.instance                                                         // 118
          });                                                                         //
        }                                                                             //
        // The marker already exists, so we'll just change its position.              //
        else {                                                                        // 115
            marker.setPosition(latLng);                                               // 123
          }                                                                           //
                                                                                      //
        // Center and zoom the map view onto the current position.                    //
        map.instance.setCenter(marker.getPosition());                                 // 109
        map.instance.setZoom(MAP_ZOOM);                                               // 128
      });                                                                             //
    });                                                                               //
  });                                                                                 //
                                                                                      //
  Template.map.helpers({                                                              // 133
    geolocationError: function () {                                                   // 134
      function geolocationError() {                                                   // 134
        var error = Geolocation.error();                                              // 135
        return error && error.message;                                                // 136
      }                                                                               //
                                                                                      //
      return geolocationError;                                                        //
    }(),                                                                              //
    mapOptions: function () {                                                         // 138
      function mapOptions() {                                                         // 138
        var latLng = Geolocation.latLng();                                            // 139
        // Initialize the map once we have the latLng.                                //
        if (GoogleMaps.loaded() && latLng) {                                          // 138
          return {                                                                    // 142
            center: new google.maps.LatLng(latLng.lat, latLng.lng),                   // 143
            zoom: MAP_ZOOM                                                            // 144
          };                                                                          //
        }                                                                             //
      }                                                                               //
                                                                                      //
      return mapOptions;                                                              //
    }()                                                                               //
  });                                                                                 //
                                                                                      //
  Accounts.ui.config({                                                                // 150
    passwordSignupFields: "USERNAME_ONLY"                                             // 151
  });                                                                                 //
}                                                                                     //
                                                                                      //
Meteor.methods({                                                                      // 155
  addTask: function () {                                                              // 156
    function addTask(text, address, type) {                                           // 156
      // Make sure the user is logged in before inserting a task                      //
                                                                                      //
      Tasks.insert({                                                                  // 159
        text: text,                                                                   // 160
        createdAt: new Date(),                                                        // 161
        address: address,                                                             // 162
        type: type                                                                    // 163
      });                                                                             //
    }                                                                                 //
                                                                                      //
    return addTask;                                                                   //
  }(),                                                                                //
  // private : false,                                                                 //
  // username: Meteor.user().username                                                 //
  deleteTask: function () {                                                           // 168
    function deleteTask(taskId) {                                                     // 168
      var task = Tasks.findOne(taskId);                                               // 169
      if (task["private"] && task.owner !== Meteor.userId()) {                        // 170
        // If the task is private, make sure only the owner can delete it             //
        throw new Meteor.Error("not-authorized");                                     // 172
      }                                                                               //
                                                                                      //
      Tasks.remove(taskId);                                                           // 175
    }                                                                                 //
                                                                                      //
    return deleteTask;                                                                //
  }(),                                                                                //
  setChecked: function () {                                                           // 177
    function setChecked(taskId, _setChecked) {                                        // 177
      var task = Tasks.findOne(taskId);                                               // 178
      if (task["private"] && task.owner !== Meteor.userId()) {                        // 179
        // If the task is private, make sure only the owner can check it off          //
        throw new Meteor.Error("not-authorized");                                     // 181
      }                                                                               //
      Tasks.update(taskId, { $set: { checked: _setChecked } });                       // 183
    }                                                                                 //
                                                                                      //
    return setChecked;                                                                //
  }(),                                                                                //
  setPrivate: function () {                                                           // 185
    function setPrivate(taskId, setToPrivate) {                                       // 185
      var task = Tasks.findOne(taskId);                                               // 186
                                                                                      //
      // Make sure only the task owner can make a task private                        //
      if (task.owner !== Meteor.userId()) {                                           // 185
        throw new Meteor.Error("not-authorized");                                     // 190
      }                                                                               //
                                                                                      //
      Tasks.update(taskId, { $set: { "private": setToPrivate } });                    // 193
    }                                                                                 //
                                                                                      //
    return setPrivate;                                                                //
  }(),                                                                                //
  setAccepted: function () {                                                          // 195
    function setAccepted(taskId) {                                                    // 195
      var task = Tasks.findOne(taskId);                                               // 196
      Tasks.update(taskId, { $set: { accepted: true } });                             // 197
    }                                                                                 //
                                                                                      //
    return setAccepted;                                                               //
  }()                                                                                 //
});                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./super_test_app_meteor.js");
//# sourceMappingURL=app.js.map
